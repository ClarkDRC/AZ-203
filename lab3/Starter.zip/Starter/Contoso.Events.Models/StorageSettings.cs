﻿namespace Contoso.Events.Models
{
    public class StorageSettings
    {
        public string ConnectionString { get; set; }

        public string ContainerName { get; set; }
    }
}